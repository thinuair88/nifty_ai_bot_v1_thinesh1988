# NIFTY Futures AI Bot (Demo)

This is a simple Streamlit dashboard that simulates an AI-based trading signal for NIFTY futures.

## How to Use

1. Clone or download the repo
2. Run `streamlit run main.py` to launch locally
3. Or deploy on [https://streamlit.io/cloud](https://streamlit.io/cloud)

## Files

- `main.py`: Streamlit app
- `requirements.txt`: Dependencies